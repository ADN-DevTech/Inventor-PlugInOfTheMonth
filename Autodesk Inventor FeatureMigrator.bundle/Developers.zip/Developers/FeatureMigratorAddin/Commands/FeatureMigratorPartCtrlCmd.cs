////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Inventor;
using Autodesk.ADN.Utility.CommandUtils;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// FeatureMigratorPartCtrlCmd Inventor Add-in Command
//  
// Author: Felipe
// Creation date: 11/10/2011 4:15:05 PM
// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
namespace FeatureMigrator
{
    class FeatureMigratorPartCtrlCmd : AdnButtonCommandBase
    {
        ApplicationAddInSite _addInSiteObject;

        FeatureMigratorDockWnd _dockableWindow;

        public FeatureMigratorPartCtrlCmd(
            Inventor.Application Application,
            ApplicationAddInSite addInSiteObject,
            FeatureMigratorDockWnd dockableWindow)
            : base(Application)
        {
            _addInSiteObject = addInSiteObject;

            _dockableWindow = dockableWindow;
        }

        public override string DisplayName
        {
            get
            {
                return "Control";
            }
        }

        public override string InternalName
        {
            get
            {
                return "Autodesk.FeatureMigrator.FeatureMigratorPartCtrlCmd";
            }
        }

        public override CommandTypesEnum Classification
        {
            get
            {
                return CommandTypesEnum.kEditMaskCmdType;
            }
        }

        public override string ClientId
        {
            get
            {
                Type t = typeof(StandardAddInServer);
                return t.GUID.ToString("B");
            }
        }

        public override string Description
        {
            get
            {
                return "Displays Feature Migrator Control";
            }
        }

        public override string ToolTipText
        {
            get
            {
                return "Displays Feature Migrator Control";
            }
        }

        public override ButtonDisplayEnum ButtonDisplay
        {
            get
            {
                return ButtonDisplayEnum.kDisplayTextInLearningMode;
            }
        }

        public override string StandardIconName
        {
            get
            {
                return "FeatureMigrator.resources.FeatureMigrator.16x16.ico";
            }
        }

        public override string LargeIconName
        {
            get
            {
                return "FeatureMigrator.resources.FeatureMigrator.32x32.ico";
            }
        }

        protected override void OnExecute(NameValueMap context)
        {
            if (_dockableWindow == null)
            {
                _dockableWindow = new FeatureMigratorDockWnd(
                    _addInSiteObject,
                    DockingStateEnum.kDockLeft);

                _dockableWindow.Show();
            }
            else
            {
                _dockableWindow.RefreshControl();
                _dockableWindow.Visible = true;
            }

            Terminate();
        }

        protected override void OnHelp(NameValueMap context)
        {

        }

        protected override void OnLinearMarkingMenu(
           ObjectsEnumerator SelectedEntities,
           SelectionDeviceEnum SelectionDevice,
           CommandControls LinearMenu,
           NameValueMap AdditionalInfo)
        {
            // Add this button to linear context menu
            //LinearMenu.AddButton(_controlDef, true, true, "", false);
        }

        protected override void OnRadialMarkingMenu(
            ObjectsEnumerator SelectedEntities,
            SelectionDeviceEnum SelectionDevice,
            RadialMarkingMenu RadialMenu,
            NameValueMap AdditionalInfo)
        {
            // Add this button to radial context menu
            //RadialMenu.NorthControl = _controlDef;
        }
    }
}
