﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Inventor;

namespace FeatureMigrator
{
    public partial class FeatureMigratorDockWnd : Form
    {
        ApplicationAddInSite _addInSite;

        ApplicationEvents _applicationEvents;

        public FeatureMigratorDockWnd(
           Inventor.ApplicationAddInSite addInSite,
           Inventor.DockingStateEnum initialDockingState)
        {
            if (addInSite == null) // We can't build the dockable window without the add-in site object.
                throw new ArgumentNullException("addInSite");

            _addInSite = addInSite;

            _applicationEvents = addInSite.Application.ApplicationEvents;

            _applicationEvents.OnActivateDocument += 
                new ApplicationEventsSink_OnActivateDocumentEventHandler(ApplicationEvents_OnActivateDocument);

            _applicationEvents.OnDeactivateDocument += 
                new ApplicationEventsSink_OnDeactivateDocumentEventHandler(ApplicationEvents_OnDeactivateDocument);

            InitializeComponent();

            _browserControl.Initialize();

            _browserControl.RefreshControl(addInSite.Application.ActiveDocument);

            // Make sure the components object is created. (The designer doesn't always create it.)
            if (components == null)
                components = new Container();

            // Create the DockableWindow using a managed wrapper and add it to the components collection.
            components.Add(
                new DockableWindowWrapper(addInSite, this, initialDockingState),
                typeof(DockableWindowWrapper).Name);
        }

        void ApplicationEvents_OnDeactivateDocument(_Document DocumentObject, EventTimingEnum BeforeOrAfter, NameValueMap Context, out HandlingCodeEnum HandlingCode)
        {
            HandlingCode = HandlingCodeEnum.kEventNotHandled;

            if (BeforeOrAfter == EventTimingEnum.kAfter)
                RefreshControl();
        }

        void ApplicationEvents_OnActivateDocument(_Document DocumentObject, EventTimingEnum BeforeOrAfter, NameValueMap Context, out HandlingCodeEnum HandlingCode)
        {
            HandlingCode = HandlingCodeEnum.kEventNotHandled;

            if (BeforeOrAfter == EventTimingEnum.kAfter)
                RefreshControl();
        }

        public void RefreshControl()
        {
            _browserControl.RefreshControl(_addInSite.Application.ActiveDocument);
        }
    }
}
