﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Philippe Leefsma 2009-2010 - ADN/Developer Technical Services
//
// Feedback and questions: Philippe.Leefsma@Autodesk.com
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the author Philippe Leefsma can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool, as it will modify the documents involved 
// in the feature migration.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Inventor;

namespace FeatureMigratorLib
{
    public partial class ReportControl : Form
    {
        private List<FeatureReport> _Reports;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public ReportControl(AssemblyDocument document, List<FeatureReport> reports)
        {
            InitializeComponent();

            _Reports = reports;

            cbAction.SelectedIndex = 0;

            lbNumberFeatures.Text += _Reports.Count.ToString();

            int nbNonHealthy = 0;
            int nbUnrefDocs = 0;

            foreach (FeatureReport report in _Reports)
            {
                foreach (ReportData data in report.ReportDataList)
                {
                    data.Load();

                    if (data.PartFeature == null) 
                        continue;

                    if (data.PartFeature.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                    {
                        ++nbNonHealthy;
                    }
                }

                nbUnrefDocs += report.UnrefDocsCount;
            }

            lbNonHealthy.Text += nbNonHealthy.ToString();

            lbUnrefDocs.Text += nbUnrefDocs.ToString();

            cbActionPart.SelectedIndex = 0;

            cbStyles.Tag = document;

            cbStyles.Items.Add("As Part");

            foreach (RenderStyle style in document.RenderStyles)
            {
                cbStyles.Items.Add(style.Name);
            }

            //Set "As Part" as default
            cbStyles.SelectedIndex = 0;

            this.FormClosing += new FormClosingEventHandler(ReportControl_FormClosing);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void ShowAsChildModal()
        {
            ShowDialog(new WindowWrapper((IntPtr)FeatureUtilities.Application.MainFrameHWND));
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ActionPreFinalize()
        {
            foreach (FeatureReport report in _Reports)
            {
                switch (cbAction.SelectedIndex)
                {
                    case 0: //Suppress if succeed

                        if (report.ReportStatus == ReportStatusEnum.kSuccess)
                        {
                            report.FinalizeAction = FinalizeActionEnum.kSuppress;
                        }
                        break;

                    case 1: //Suppress always

                        report.FinalizeAction = FinalizeActionEnum.kSuppress;
                        break;

                    case 2: //Delete if succeed

                        if (report.ReportStatus == ReportStatusEnum.kSuccess)
                        {
                            report.FinalizeAction = FinalizeActionEnum.kDeleteAll;
                        }
                        break;

                    case 3: //Delete always

                        report.FinalizeAction = FinalizeActionEnum.kDeleteAll;
                        break;

                    case 4: //None
                    default:
                        break;
                }

                report.Style = cbStyles.Text;

                foreach (ReportData data in report.ReportDataList)
                {
                    if (data.PartFeature == null) 
                        continue;

                    if (data.PartFeature.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                    {
                        switch (cbActionPart.SelectedIndex)
                        {
                            case 0: //Suppress
                                data.FinalizeAction = FinalizeActionEnum.kSuppress;
                                break;

                            case 1: //delete
                                data.FinalizeAction = FinalizeActionEnum.kDeleteAll;
                                break;

                            case 2: //None
                                data.FinalizeAction = FinalizeActionEnum.kNone;
                                break;

                            default:
                                break;
                        }
                    }
                }

                report.SetAllUnrefDocsAction(cbUnrefDocs.Checked);
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ActionFinalize()
        {
            foreach (FeatureReport report in _Reports)
            {
                report.ActionFinalize();
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void bOk_Click(object sender, EventArgs e)
        {
            ActionPreFinalize();

            ActionFinalize();

            Close();
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // User closed the form without clicking Ok, so do not perform any action
        // just close all loaded part documents
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        void ReportControl_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (FeatureReport report in _Reports)
            {
                report.UnloadReportData();
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void bDetail_Click(object sender, EventArgs e)
        {
            ActionPreFinalize();

            Hide();
            Close();

            DetailReportControl detailReportControl = new DetailReportControl(cbStyles.Tag as AssemblyDocument, _Reports);
              
            detailReportControl.ShowAsChildModal();
        }
    }
}
