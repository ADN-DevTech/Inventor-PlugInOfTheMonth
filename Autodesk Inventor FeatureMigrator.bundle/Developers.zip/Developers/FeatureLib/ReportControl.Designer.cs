﻿namespace FeatureMigratorLib
{
    partial class ReportControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReportControl));
            this.label2 = new System.Windows.Forms.Label();
            this.cbStyles = new System.Windows.Forms.ComboBox();
            this.cbAction = new System.Windows.Forms.ComboBox();
            this.lbAction = new System.Windows.Forms.Label();
            this.bOk = new System.Windows.Forms.Button();
            this.bDetail = new System.Windows.Forms.Button();
            this.cbUnrefDocs = new System.Windows.Forms.CheckBox();
            this.cbActionPart = new System.Windows.Forms.ComboBox();
            this.lbFeaturesError = new System.Windows.Forms.Label();
            this.lbNumberFeatures = new System.Windows.Forms.Label();
            this.lbNonHealthy = new System.Windows.Forms.Label();
            this.lbUnrefDocs = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Part Features Render Style:";
            // 
            // cbStyles
            // 
            this.cbStyles.DropDownHeight = 200;
            this.cbStyles.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStyles.FormattingEnabled = true;
            this.cbStyles.IntegralHeight = false;
            this.cbStyles.Location = new System.Drawing.Point(202, 84);
            this.cbStyles.Name = "cbStyles";
            this.cbStyles.Size = new System.Drawing.Size(172, 21);
            this.cbStyles.TabIndex = 27;
            // 
            // cbAction
            // 
            this.cbAction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbAction.FormattingEnabled = true;
            this.cbAction.Items.AddRange(new object[] {
            "Suppress if Succeeded",
            "Suppress always",
            "Delete if Succeeded",
            "Delete always",
            "None"});
            this.cbAction.Location = new System.Drawing.Point(201, 53);
            this.cbAction.Name = "cbAction";
            this.cbAction.Size = new System.Drawing.Size(173, 21);
            this.cbAction.TabIndex = 23;
            // 
            // lbAction
            // 
            this.lbAction.AutoSize = true;
            this.lbAction.Location = new System.Drawing.Point(6, 56);
            this.lbAction.Name = "lbAction";
            this.lbAction.Size = new System.Drawing.Size(146, 13);
            this.lbAction.TabIndex = 22;
            this.lbAction.Text = "Action for Assembly Features:";
            // 
            // bOk
            // 
            this.bOk.Location = new System.Drawing.Point(242, 293);
            this.bOk.Name = "bOk";
            this.bOk.Size = new System.Drawing.Size(145, 27);
            this.bOk.TabIndex = 29;
            this.bOk.Text = "OK";
            this.bOk.UseVisualStyleBackColor = true;
            this.bOk.Click += new System.EventHandler(this.bOk_Click);
            // 
            // bDetail
            // 
            this.bDetail.Location = new System.Drawing.Point(130, 293);
            this.bDetail.Name = "bDetail";
            this.bDetail.Size = new System.Drawing.Size(106, 27);
            this.bDetail.TabIndex = 30;
            this.bDetail.Text = "+ Detailed Report";
            this.bDetail.UseVisualStyleBackColor = true;
            this.bDetail.Click += new System.EventHandler(this.bDetail_Click);
            // 
            // cbUnrefDocs
            // 
            this.cbUnrefDocs.AutoSize = true;
            this.cbUnrefDocs.Location = new System.Drawing.Point(8, 39);
            this.cbUnrefDocs.Name = "cbUnrefDocs";
            this.cbUnrefDocs.Size = new System.Drawing.Size(191, 17);
            this.cbUnrefDocs.TabIndex = 31;
            this.cbUnrefDocs.Text = "Delete all unreferenced documents";
            this.cbUnrefDocs.UseVisualStyleBackColor = true;
            // 
            // cbActionPart
            // 
            this.cbActionPart.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbActionPart.FormattingEnabled = true;
            this.cbActionPart.Items.AddRange(new object[] {
            "Suppress",
            "Delete",
            "None"});
            this.cbActionPart.Location = new System.Drawing.Point(202, 49);
            this.cbActionPart.Name = "cbActionPart";
            this.cbActionPart.Size = new System.Drawing.Size(172, 21);
            this.cbActionPart.TabIndex = 32;
            // 
            // lbFeaturesError
            // 
            this.lbFeaturesError.AutoSize = true;
            this.lbFeaturesError.Location = new System.Drawing.Point(6, 52);
            this.lbFeaturesError.Name = "lbFeaturesError";
            this.lbFeaturesError.Size = new System.Drawing.Size(157, 13);
            this.lbFeaturesError.TabIndex = 33;
            this.lbFeaturesError.Text = "Action for non healthy Features:";
            // 
            // lbNumberFeatures
            // 
            this.lbNumberFeatures.AutoSize = true;
            this.lbNumberFeatures.Location = new System.Drawing.Point(6, 27);
            this.lbNumberFeatures.Name = "lbNumberFeatures";
            this.lbNumberFeatures.Size = new System.Drawing.Size(214, 13);
            this.lbNumberFeatures.TabIndex = 34;
            this.lbNumberFeatures.Text = "Number of Assembly Features sent to parts: ";
            // 
            // lbNonHealthy
            // 
            this.lbNonHealthy.AutoSize = true;
            this.lbNonHealthy.Location = new System.Drawing.Point(6, 25);
            this.lbNonHealthy.Name = "lbNonHealthy";
            this.lbNonHealthy.Size = new System.Drawing.Size(201, 13);
            this.lbNonHealthy.TabIndex = 35;
            this.lbNonHealthy.Text = "Number of non healthy Features in parts: ";
            // 
            // lbUnrefDocs
            // 
            this.lbUnrefDocs.AutoSize = true;
            this.lbUnrefDocs.Location = new System.Drawing.Point(6, 16);
            this.lbUnrefDocs.Name = "lbUnrefDocs";
            this.lbUnrefDocs.Size = new System.Drawing.Size(183, 13);
            this.lbUnrefDocs.TabIndex = 36;
            this.lbUnrefDocs.Text = "Number of unreferenced documents: ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbNumberFeatures);
            this.groupBox1.Controls.Add(this.lbAction);
            this.groupBox1.Controls.Add(this.cbAction);
            this.groupBox1.Location = new System.Drawing.Point(5, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(382, 84);
            this.groupBox1.TabIndex = 37;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Assembly Features:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lbNonHealthy);
            this.groupBox2.Controls.Add(this.cbActionPart);
            this.groupBox2.Controls.Add(this.lbFeaturesError);
            this.groupBox2.Controls.Add(this.cbStyles);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(5, 97);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(382, 115);
            this.groupBox2.TabIndex = 38;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Part Features:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbUnrefDocs);
            this.groupBox3.Controls.Add(this.cbUnrefDocs);
            this.groupBox3.Location = new System.Drawing.Point(5, 218);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(382, 67);
            this.groupBox3.TabIndex = 39;
            this.groupBox3.TabStop = false;
            // 
            // ReportControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 328);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.bDetail);
            this.Controls.Add(this.bOk);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ReportControl";
            this.Text = "Features Migration - Global Report";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbStyles;
        private System.Windows.Forms.ComboBox cbAction;
        private System.Windows.Forms.Label lbAction;
        private System.Windows.Forms.Button bOk;
        private System.Windows.Forms.Button bDetail;
        private System.Windows.Forms.CheckBox cbUnrefDocs;
        private System.Windows.Forms.ComboBox cbActionPart;
        private System.Windows.Forms.Label lbFeaturesError;
        private System.Windows.Forms.Label lbNumberFeatures;
        private System.Windows.Forms.Label lbNonHealthy;
        private System.Windows.Forms.Label lbUnrefDocs;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}