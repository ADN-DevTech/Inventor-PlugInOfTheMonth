﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Philippe Leefsma 2009-2010 - ADN/Developer Technical Services
//
// Feedback and questions: Philippe.Leefsma@Autodesk.com
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the author Philippe Leefsma can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool, as it will modify the documents involved 
// in the feature migration.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using Inventor;

namespace FeatureMigratorLib
{
    public class ExtrudeFeatureMigrator : IFeatureMigrator
    {
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool IsMigrationSupported(PartFeature AsmFeature)
        {
            return (AsmFeature is ExtrudeFeature);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool IsAssociativitySupported(PartFeature PartFeature)
        {
            return (PartFeature is ExtrudeFeature);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public FeatureReport SendToParts(AssemblyDocument ParentDocument, 
            List<ComponentOccurrence> Participants, 
            PartFeature AsmFeature)
        {
            ExtrudeFeature extrudeFeature = AsmFeature as ExtrudeFeature;

            FeatureReport result = new FeatureReport(AsmFeature);

            result.UnreferencedDocuments = FeatureUtilities.ReplaceOccurrences(ParentDocument, Participants);

            PlanarSketch asmSketch = extrudeFeature.Profile.Parent as PlanarSketch;
            
            foreach (ComponentOccurrence occurrence in Participants)
            {
                if (!FeatureUtilities.IsValidOccurrence(occurrence))
                {
                    continue;
                }

                Matrix invTransfo = occurrence.Transformation;
                invTransfo.Invert();

                PartComponentDefinition partCompDef = occurrence.Definition as PartComponentDefinition;

                PartFeature newFeature = CopyFeature(partCompDef, AsmFeature, invTransfo);
                  
                //Place Feature Tag: associativity handling
                FeatureAttributeManager.CreatePartFeatureTag(ParentDocument, 
                    AsmFeature, 
                    newFeature,
                    occurrence);

                ReportData reportData = new ReportData(partCompDef.Document as PartDocument, 
                    newFeature);

                result.addReportData(reportData);
            }
    
            return result;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public ExtrudeDefinition CopyExtrudeDefinitionBase(
            PartComponentDefinition partCompDef,
            ExtrudeFeature extrudeFeature,
            Profile partProfile)
        {
            ExtrudeDefinition extrudeDef = partCompDef.Features.ExtrudeFeatures.CreateExtrudeDefinition(
                partProfile,
                extrudeFeature.Operation);

            ObjectCollection bodies = FeatureUtilities.Application.TransientObjects.CreateObjectCollection();

            foreach(SurfaceBody body in partCompDef.SurfaceBodies)
                bodies.Add(body);

            extrudeDef.AffectedBodies = bodies;

            dynamic partTaperAngle = extrudeDef.TaperAngle;
            dynamic asmTaperAngle = extrudeFeature.Definition.TaperAngle;

            partTaperAngle = asmTaperAngle.Value;
            
            return extrudeDef;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public PartFeature CopyFeature(
            PartComponentDefinition partCompDef,
            PartFeature asmFeature,
            Matrix invTransfo)
        {
            try
            {
                ExtrudeFeature extrudeFeature = asmFeature as ExtrudeFeature;

                ExtrudeFeature newFeature = null;

                UnitVector xAxis = null;
                UnitVector yAxis = null;

                PlanarSketch asmSketch = extrudeFeature.Profile.Parent as PlanarSketch;

                PlanarSketch partSketch = FeatureUtilities.CopySketch(partCompDef, 
                    asmSketch, 
                    invTransfo, 
                    out xAxis, 
                    out yAxis);

                ObjectCollection pathSegments = FeatureUtilities.GetPathSegments(
                    extrudeFeature.Profile,
                    partSketch);

                Profile partProfile = partSketch.Profiles.AddForSolid(true, pathSegments, null);

                FeatureUtilities.CopyProfile(extrudeFeature.Profile, partProfile);

                ExtrudeDefinition extrudeDef = 
                    CopyExtrudeDefinitionBase(partCompDef, extrudeFeature, partProfile);

                switch (extrudeFeature.Definition.ExtentType)
                {
                    case PartFeatureExtentEnum.kThroughAllExtent:
                    {
                        ThroughAllExtent ThroughAllExtent = extrudeFeature.Definition.Extent as ThroughAllExtent;

                        extrudeDef.SetThroughAllExtent(ThroughAllExtent.Direction);
                      
                        break;
                    }
                    case PartFeatureExtentEnum.kDistanceExtent:
                    {
                        DistanceExtent distanceExtent1 = extrudeFeature.Definition.Extent as DistanceExtent;
                       
                        extrudeDef.SetDistanceExtent(distanceExtent1.Distance.Value, distanceExtent1.Direction);

                        if (extrudeFeature.Definition.IsTwoDirectional)
                        {
                            DistanceExtent distanceExtent2 = extrudeFeature.Definition.ExtentTwo as DistanceExtent;
                            extrudeDef.SetDistanceExtentTwo(distanceExtent2.Distance.Value);
                            extrudeDef.TaperAngleTwo = extrudeFeature.Definition.TaperAngleTwo;

                            dynamic partTaperAngle = extrudeDef.TaperAngleTwo;
                            dynamic asmTaperAngle = extrudeFeature.Definition.TaperAngleTwo;

                            partTaperAngle = asmTaperAngle.Value;
                        }

                        break;
                    }
                    case PartFeatureExtentEnum.kToExtent:
                    {
                        ToExtent ToExtent = extrudeFeature.Definition.Extent as ToExtent;

                        object ToEntity = FeatureUtilities.CopyFromToEntity(
                            ToExtent.ToEntity,
                            partCompDef,
                            invTransfo);

                        extrudeDef.SetToExtent(ToEntity, false);

                        break;
                    }
                    case PartFeatureExtentEnum.kFromToExtent:
                    {
                        FromToExtent FromToExtent =extrudeFeature.Definition.Extent as FromToExtent;

                        object FromEntity = FeatureUtilities.CopyFromToEntity(FromToExtent.FromFace,
                            partCompDef,
                            invTransfo);

                        object ToEntity = FeatureUtilities.CopyFromToEntity(FromToExtent.ToFace,
                            partCompDef,
                            invTransfo);

                        extrudeDef.SetFromToExtent(FromEntity, false, ToEntity, false);

                        break;
                    }
                    case PartFeatureExtentEnum.kToNextExtent:
                    {
                        //Not supported, terminator surface body not in part context
                        break;
                    }
                    
                    default:
                        break;
                }

                newFeature = partCompDef.Features.ExtrudeFeatures.Add(extrudeDef);

                return newFeature as PartFeature;
            }
            catch
            {
                return null;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool IsPartFeatureUpToDate(PartFeature AsmFeature, 
            PartFeature PartFeature, 
            Matrix invTransfo)
        {
            ExtrudeFeature asmFeature = AsmFeature as ExtrudeFeature;
            ExtrudeFeature partFeature = PartFeature as ExtrudeFeature;

            try
            {
                PlanarSketch asmSketch = asmFeature.Profile.Parent as PlanarSketch;
                PlanarSketch partSketch = partFeature.Profile.Parent as PlanarSketch;

                if (!FeatureUtilities.CompareSketches(asmSketch, partSketch, invTransfo))
                    return false;

                if (!FeatureUtilities.CompareProfiles(asmFeature.Profile, partFeature.Profile))
                    return false;

                if (!FeatureUtilities.IsEqual(asmFeature.TaperAngle.Value, partFeature.TaperAngle.Value))
                    return false;

                if (!FeatureUtilities.CompareFeatureExtents(asmFeature.Definition.Extent, partFeature.Definition.Extent, invTransfo))
                    return false;

                if(asmFeature.Definition.IsTwoDirectional != partFeature.Definition.IsTwoDirectional)
                    return false;

                if (asmFeature.Definition.IsTwoDirectional)
                {
                    if (!FeatureUtilities.CompareFeatureExtents(
                            asmFeature.Definition.ExtentTwo,
                            partFeature.Definition.ExtentTwo, invTransfo))
                        return false;

                    dynamic partTaperAngle = partFeature.Definition.TaperAngleTwo;

                    if (!FeatureUtilities.IsEqual(asmFeature.TaperAngleTwo.Value, partTaperAngle.Value))
                        return false;
                }

                return true;
            }
            catch
            {
                //Something went wrong
                return false;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool UpdateFeatureFromAsm(
            PartFeature AsmFeature,
            PartFeature PartFeature,
            Matrix invTransfo)
        {
            ExtrudeFeature asmFeature = AsmFeature as ExtrudeFeature;
            ExtrudeFeature partFeature = PartFeature as ExtrudeFeature;

            try
            {
                PartComponentDefinition partCompDef = partFeature.Parent as PartComponentDefinition;

                PlanarSketch partSketch = partFeature.Profile.Parent as PlanarSketch;

                UnitVector xAxis = null;
                UnitVector yAxis = null;

                FeatureUtilities.UpdateSketch(asmFeature.Profile.Parent as PlanarSketch,
                        partSketch,
                        invTransfo,
                        out xAxis,
                        out yAxis);

                Document asmDocument = asmFeature.Parent.Document as Document;

                bool suppressed = partFeature.Suppressed;

                //Feature needs to be suppressed if we change the Profile
                partFeature.Suppressed = true;

                Profile newPartProfile = FeatureUtilities.UpdateProfile(asmDocument,
                    partCompDef.Document as Document,
                    asmFeature.Profile,
                    partFeature.Profile,
                    true);

                if (newPartProfile != null)
                {
                    partFeature.Profile = newPartProfile;
                }

                partFeature.Suppressed = suppressed;

                if (FeatureUtilities.UpdateFeatureExtent(asmFeature.Definition, partFeature.Definition, invTransfo))
                    return true;

                switch (asmFeature.ExtentType)
                {
                    case PartFeatureExtentEnum.kThroughAllExtent:
                    {
                        ThroughAllExtent asmThroughAllExtent = asmFeature.Definition.Extent as ThroughAllExtent;

                        partFeature.Definition.SetThroughAllExtent(asmThroughAllExtent.Direction);

                        break;
                    }
                    case PartFeatureExtentEnum.kDistanceExtent:
                    {
                        DistanceExtent asmDistanceExtent1 = asmFeature.Definition.Extent as DistanceExtent;
                        partFeature.Definition.SetDistanceExtent(asmDistanceExtent1.Distance.Value, asmDistanceExtent1.Direction);

                        if (asmFeature.Definition.IsTwoDirectional)
                        {
                            DistanceExtent asmDistanceExtent2 = asmFeature.Definition.ExtentTwo as DistanceExtent;
                            partFeature.Definition.SetDistanceExtentTwo(asmDistanceExtent2.Distance.Value);
                           
                            dynamic partTaperAngle2 = partFeature.Definition.TaperAngleTwo;
                            dynamic asmTaperAngle2 = asmFeature.Definition.TaperAngleTwo;

                            partTaperAngle2.Value = asmTaperAngle2.Value;
                        }

                        break;
                    }
                    case PartFeatureExtentEnum.kToExtent:
                    {
                        ToExtent asmToExtent = asmFeature.Definition.Extent as ToExtent;

                        object ToEntity = FeatureUtilities.CopyFromToEntity(asmToExtent.ToEntity,
                           partCompDef,
                           invTransfo);

                        partFeature.Definition.SetToExtent(ToEntity, false);

                        break;
                    }
                    case PartFeatureExtentEnum.kFromToExtent:
                    {
                        FromToExtent asmFromToExtent = asmFeature.Definition.Extent as FromToExtent;

                        object FromEntity = FeatureUtilities.CopyFromToEntity(asmFromToExtent.FromFace,
                           partCompDef,
                           invTransfo);

                        object ToEntity = FeatureUtilities.CopyFromToEntity(asmFromToExtent.ToFace,
                           partCompDef,
                           invTransfo);

                        partFeature.Definition.SetFromToExtent(FromEntity, false, ToEntity, false);

                        break;
                    }
                    default:
                        return false;
                }

                return true;
            }
            catch
            {
                //Something went wrong
                return false;
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        //
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static string GetSketchBase(ExtrudeFeature extrudeFeature)
        {
            PlanarSketch sketch = extrudeFeature.Profile.Parent as PlanarSketch;

            return (sketch.PlanarEntity is WorkPlane ? "WorkPlane" : "Face");
        }
    }
}
