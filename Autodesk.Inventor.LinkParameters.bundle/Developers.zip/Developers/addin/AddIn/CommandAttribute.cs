﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the authors can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;

namespace Autodesk.ADN.LinkParameters.AddIn
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple=false, Inherited=true)]
    public sealed class CommandAttribute : Attribute
    {
        #region Fields

        private string _internalName;

        #endregion

        public CommandAttribute(string internalName)
        {
            _internalName = internalName;
        }

        public string InternalName
        {
            get { return _internalName; }
        }
    }
}
