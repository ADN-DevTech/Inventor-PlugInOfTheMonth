﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the authors can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;

namespace Autodesk.ADN.LinkParameters.AddIn
{
    class CommandRegistry : IEnumerable<Command>
    {
        #region Fields

        private List<Command> _commands = new List<Command>();

        #endregion

        public CommandRegistry(global::Inventor.Application app)
        {
            Application = app;
            AttachEvents();
        }

        #region IEnumerable<Command> Members

        public IEnumerator<Command> GetEnumerator()
        {
            return _commands.GetEnumerator();
        }

        #endregion

        #region IEnumerable Members

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }

        #endregion

        protected global::Inventor.Application Application { get; private set; }

        protected global::Inventor.UserInputEvents InputEvents { get; private set; }

        public void RegisterCommands(Assembly assembly)
        {
            DiscoverCommands(assembly);
        }

        public void UnregisterCommands()
        {
            foreach (Command command in _commands)
            {
                command.Remove();
            }
            _commands.Clear();
            DetachEvents();
        }

        private void AttachEvents()
        {
            InputEvents = Application.CommandManager.UserInputEvents;
            InputEvents.OnContextMenu += new global::Inventor.UserInputEventsSink_OnContextMenuEventHandler(Handle_InputEvents_OnContextMenu);
        }

        private void DetachEvents()
        {
            if (InputEvents != null)
            {
                InputEvents.OnContextMenu -= new global::Inventor.UserInputEventsSink_OnContextMenuEventHandler(Handle_InputEvents_OnContextMenu);
                InputEvents = null;
            }
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        private void DiscoverCommands(Assembly assembly)
        {
            var types = from t in assembly.GetTypes() where Attribute.GetCustomAttribute(t, typeof(CommandAttribute)) != null select t;

            foreach (Type t in types)
            {
                try
                {
                    Command cmd = (Command)Activator.CreateInstance(t);

                    cmd.Application = AddInServer.Instance.Application;
                    cmd.CreateControl();
                    _commands.Add(cmd);
                }
                catch
                {
                }
            }
        }

        private void Handle_InputEvents_OnContextMenu(global::Inventor.SelectionDeviceEnum selectionDevice, 
            global::Inventor.NameValueMap context, 
            global::Inventor.CommandBar commandBar)
        {
            foreach (Command cmd in _commands)
            {
                cmd.RegisterContextMenu(selectionDevice, context, commandBar);
            }
        }

    }
}
