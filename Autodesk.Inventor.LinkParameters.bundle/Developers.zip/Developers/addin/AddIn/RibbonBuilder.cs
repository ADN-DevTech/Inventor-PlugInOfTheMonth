﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the authors can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml;

namespace Autodesk.ADN.LinkParameters.AddIn
{
    class RibbonBuilder
    {
        private RibbonBuilder(global::Inventor.Application app)
        {
            Application = app;
            CommandManager = app.CommandManager;
        }

        private global::Inventor.Application Application { get; set; }
        private global::Inventor.CommandManager CommandManager { get; set; }

        public static void CreateRibbon(global::Inventor.Application app, Stream stream)
        {
            new RibbonBuilder(app).DoCreateRibbon(stream);
        }

        public static void CreateRibbon(global::Inventor.Application app, string fileName)
        {
            new RibbonBuilder(app).DoCreateRibbon(fileName);
        }

        private void DoCreateRibbon(Stream stream)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(stream);
            ProcessDocument(xdoc);
        }

        private void DoCreateRibbon(string fileName)
        {
            XmlDocument xdoc = new XmlDocument();

            xdoc.Load(fileName);
            ProcessDocument(xdoc);
        }

        private void ProcessDocument(XmlDocument xdoc)
        {
            XmlNodeList tabNodes = xdoc.SelectNodes("//RibbonTab");

            foreach (XmlNode tabNode in tabNodes)
            {
                ProcessTabNode(tabNode);
            }
        }

        private void ProcessTabNode(XmlNode node)
        {
            global::Inventor.UserInterfaceManager uiManager = Application.UserInterfaceManager;
            string[] ribbonNames = node.Attributes["ribbons"].Value.Split('|');
            string displayName = node.Attributes["displayName"].Value,
                internalName = node.Attributes["internalName"].Value,
                targetTab = node.Attributes["targetTab"].Value;
            bool insertBefore = Convert.ToBoolean(node.Attributes["insertBefore"].Value, CultureInfo.InvariantCulture);

            foreach (global::Inventor.Ribbon ribbon in uiManager.Ribbons)
            {
                if (ribbonNames.Contains(ribbon.InternalName) == false)
                {
                    continue;
                }
                global::Inventor.RibbonTab tab = ribbon.RibbonTabs.OfType<global::Inventor.RibbonTab>().SingleOrDefault(t => t.InternalName == internalName);

                if (tab == null)
                {
                    tab = ribbon.RibbonTabs.Add(displayName, internalName, Globals.AddInGUIDRegString, targetTab, insertBefore, false);
                }
                XmlNodeList panelNodes = node.SelectNodes("RibbonPanel");

                foreach (XmlNode panelNode in panelNodes)
                {
                    ProcessPanelNode(tab, panelNode);
                }
            }
        }

        private void ProcessPanelNode(global::Inventor.RibbonTab tab, XmlNode node)
        {
            string displayName = node.Attributes["displayName"].Value;
            string internalName = node.Attributes["internalName"].Value;
            string targetPanel = string.Empty;

            XmlAttribute attrTargetPanel = (XmlAttribute)node.Attributes.GetNamedItem("targetPanel");

            if (attrTargetPanel != null)
            {
                targetPanel = attrTargetPanel.Value;
            }
            bool? insertBefore = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "insertBefore");

            global::Inventor.RibbonPanel panel = tab.RibbonPanels.OfType<global::Inventor.RibbonPanel>().SingleOrDefault(p => p.InternalName == internalName);

            if (panel == null)
            {
                panel = tab.RibbonPanels.Add(displayName, internalName, Globals.AddInGUIDRegString, targetPanel, insertBefore.HasValue ? insertBefore.Value : false);
            }
            foreach (XmlNode childNode in node.ChildNodes)
            {
                Action<global::Inventor.RibbonPanel, XmlNode> processMethod = null;

                if (childNode.Name == "CommandButton")
                {
                    processMethod = new Action<global::Inventor.RibbonPanel, XmlNode>(ProcessCommandButtonNode);
                }
                else if (childNode.Name == "Separator")
                {
                    processMethod = new Action<global::Inventor.RibbonPanel, XmlNode>(ProcessSeparatorNode);
                }
                else if (childNode.Name == "ButtonPopup")
                {
                    processMethod = new Action<global::Inventor.RibbonPanel, XmlNode>(ProcessButtonPopupNode);
                }
                else if (childNode.Name == "Popup")
                {
                    processMethod = new Action<global::Inventor.RibbonPanel, XmlNode>(ProcessPopupNode);
                }
                if (processMethod != null)
                {
                    try
                    {
                        processMethod.Invoke(panel, childNode);
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void ProcessCommandButtonNode(global::Inventor.RibbonPanel panel, XmlNode node)
        {
            string commandName = node.Attributes["commandId"].Value;

            bool? useLargeIcon = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "useLargeIcon");
            bool? showText = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "showText");
            bool? insertBefore = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "insertBefore");
            bool? isInSlideout = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "isInSlideout");

            string targetControl = XmlUtilities.GetAttributeValue<string>(node, "targetControl");

            global::Inventor.ButtonDefinition buttonDef = 
                CommandManager.ControlDefinitions[commandName] as global::Inventor.ButtonDefinition;

            bool slideout = isInSlideout.HasValue ? isInSlideout.Value : false;

            if (slideout)
            {
                panel.SlideoutControls.AddButton(buttonDef,
                    useLargeIcon.HasValue ? useLargeIcon.Value : false,
                    showText.HasValue ? showText.Value : true,
                    string.IsNullOrEmpty(targetControl) ? string.Empty : targetControl,
                    insertBefore.HasValue ? insertBefore.Value : false);
            }
            else
            {
                panel.CommandControls.AddButton(buttonDef, 
                    useLargeIcon.HasValue ? useLargeIcon.Value : false,
                    showText.HasValue ? showText.Value : true,
                    string.IsNullOrEmpty(targetControl) ? string.Empty : targetControl,
                    insertBefore.HasValue ? insertBefore.Value : false);
            }
        }

        private void ProcessSeparatorNode(global::Inventor.RibbonPanel panel, XmlNode node)
        {
            panel.CommandControls.AddSeparator(string.Empty, false);
        }

        private void ProcessButtonPopupNode(global::Inventor.RibbonPanel panel, XmlNode node)
        {
            global::Inventor.ObjectCollection buttons = GetButtons(node);
            bool? useLargeIcon = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "useLargeIcon"),
                showText = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "showText");

            if (buttons.Count > 0)
            {
                panel.CommandControls.AddButtonPopup(buttons, useLargeIcon.HasValue ? useLargeIcon.Value : false,
                    showText.HasValue ? showText.Value : true, string.Empty, false);
            }
        }

        private void ProcessPopupNode(global::Inventor.RibbonPanel panel, XmlNode node)
        {
            string commandName = node.Attributes["commandId"].Value;
            global::Inventor.ButtonDefinition button = CommandManager.ControlDefinitions[commandName] as global::Inventor.ButtonDefinition;
            global::Inventor.ObjectCollection buttons = GetButtons(node);
            bool? useLargeIcon = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "useLargeIcon"),
                showText = XmlUtilities.GetAttributeValueAsNullable<bool>(node, "showText");

            if (buttons.Count > 0)
            {
                panel.CommandControls.AddPopup(button, buttons, 
                    useLargeIcon.HasValue ? useLargeIcon.Value : false,
                    showText.HasValue ? showText.Value : true,
                    string.Empty, false);
            }
        }

        private global::Inventor.ObjectCollection GetButtons(XmlNode node)
        {
            global::Inventor.ObjectCollection buttons = Application.TransientObjects.CreateObjectCollection(Type.Missing);
            XmlNodeList nodes = node.SelectNodes("CommandButton");

            foreach (XmlNode buttonNode in nodes)
            {
                string commandName = buttonNode.Attributes["commandId"].Value;
                global::Inventor.ButtonDefinition buttonDef = CommandManager.ControlDefinitions[commandName] as global::Inventor.ButtonDefinition;

                if (buttonDef != null)
                {
                    buttons.Add(buttonDef);
                }
            }
            return buttons;
        }

    }
}
