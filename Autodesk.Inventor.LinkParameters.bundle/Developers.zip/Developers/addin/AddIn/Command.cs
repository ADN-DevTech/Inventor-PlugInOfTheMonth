﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the authors can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;

namespace Autodesk.ADN.LinkParameters.AddIn
{
    abstract class Command
    {
        protected Command()
        {
        }

        abstract public global::Inventor.ControlDefinition ControlDefinition
        {
            get;
        }

        abstract public string DisplayName
        {
            get;
        }

        abstract public string Description
        {
            get;
        }

        abstract public string ToolTipText
        {
            get;
        }

        abstract public void CreateControl();

        public virtual global::Inventor.CommandTypesEnum Classification
        {
            get { return global::Inventor.CommandTypesEnum.kEditMaskCmdType; }
        }

        public virtual global::Inventor.ButtonDisplayEnum ButtonDisplay
        {
            get { return global::Inventor.ButtonDisplayEnum.kDisplayTextInLearningMode; }
        }

        public global::Inventor.Application Application { get; internal set; }

        public string InternalName
        {
            get
            {
                CommandAttribute attr = Attribute.GetCustomAttribute(GetType(), typeof(CommandAttribute)) as CommandAttribute;

                return attr.InternalName;
            }
        }

        public void Remove()
        {
            OnRemove();
            if (ControlDefinition != null)
            {
                ControlDefinition.Delete();
            }
        }

        internal void RegisterContextMenu(global::Inventor.SelectionDeviceEnum selectionDevice, 
            global::Inventor.NameValueMap context, 
            global::Inventor.CommandBar commandBar)
        {
            OnContextMenu(selectionDevice, context, commandBar);
        }

        protected virtual void OnContextMenu(global::Inventor.SelectionDeviceEnum selectionDevice, 
            global::Inventor.NameValueMap context, 
            global::Inventor.CommandBar commandBar)
        {
        }

        protected virtual void OnRemove()
        {
        }

    }
}
