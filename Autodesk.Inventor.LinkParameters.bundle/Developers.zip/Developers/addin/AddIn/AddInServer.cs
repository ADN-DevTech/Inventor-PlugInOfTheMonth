﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the authors can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;

namespace Autodesk.ADN.LinkParameters.AddIn
{
    [Guid(Globals.AddInGUID)]
    [ComVisible(true)]
    public class AddInServer : global::Inventor.ApplicationAddInServer
    {
        #region Fields

        private static AddInServer _instance;

        private global::Inventor.Application _application;
        private CommandRegistry _commands;

        #endregion

        #region ApplicationAddInServer Members

        public object Automation
        {
            get { return null; }
        }

        public void Activate(global::Inventor.ApplicationAddInSite site, bool firstTime)
        {
            _instance = this;
            _application = site.Application;

            InventorUtilities.Initialize(_application);

            _commands = new CommandRegistry(Application);
            _commands.RegisterCommands(GetType().Assembly);

            RibbonBuilder.CreateRibbon(Application,
                GetType().Assembly.GetManifestResourceStream("Autodesk.ADN.LinkParameters.Resources.AddInUI.xml"));

            //Prevent user from unloading the add-in (except at Inventor shutdown).
            //This workarounds an issue concerning unloading/reloading an addin that
            //creates controls in a native Inventor Panel.
            site.Parent.UserUnloadable = false;
            
            AssemblyResolver.Paths.Add(InventorUtilities.iLogicPath);
            AssemblyResolver.Start();
        }

        public void Deactivate()
        {
            _commands.UnregisterCommands();
            _instance = null;
            Marshal.ReleaseComObject(_application);
            _application = null;
            AssemblyResolver.Stop();
        }

        public void ExecuteCommand(int commandId)
        {
        }

        #endregion

        #region COM Registration

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [ComRegisterFunction]
        private static void Register(Type t)
        {
            try
            {
                AddInRegistration.RegisterAddIn(t);
            }
            catch
            {
            }
        }

        [SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        [ComUnregisterFunction]
        private static void Unregister(Type t)
        {
            try
            {
                AddInRegistration.UnregisterAddIn(t);
            }
            catch
            {
            }
        }

        #endregion

        public static AddInServer Instance
        {
            get { return _instance; }
        }

        public global::Inventor.Application Application
        {
            get { return _application; }
        }

    }
}
