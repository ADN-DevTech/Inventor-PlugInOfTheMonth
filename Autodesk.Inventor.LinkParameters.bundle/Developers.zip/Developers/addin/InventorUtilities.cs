﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the authors can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Text;

using Inventor;
using Autodesk.iLogic.Interfaces;

namespace Autodesk.ADN.LinkParameters
{
    class InventorUtilities
    {
        private static Inventor.Application _Application = null;

        private InventorUtilities() { }

        public static void Initialize(Inventor.Application Application)
        {
            _Application = Application;
        }

        public static Inventor.Application Application
        {
            get
            {
                return _Application;
            }
        }

        public static string iLogicPath
        {
            get 
            { 
                return GetInventorPath() + @"\iLogicBin"; 
            }
        }

        public static string ConvertModelValue(double modelValue, string units)
        {
            double result = modelValue;

            if (units.Equals("deg"))
            {
                result = modelValue * 180.0 / Math.PI;
            }
            if (units.Equals("mm"))
            {
                result = modelValue * 10.0;
            }
            return Convert.ToString(result, CultureInfo.InvariantCulture);
        }

        public static string GetStringFromValue(double value, Inventor.UnitsTypeEnum unitsSpecifier)
        {
            return Application.UnitsOfMeasure.GetStringFromValue(value, unitsSpecifier);
        }

        public static string GetStringFromValue(double value, string units)
        {
            Inventor.UnitsTypeEnum unitsSpecifier = Inventor.UnitsTypeEnum.kDefaultDisplayLengthUnits;

            if (units.Equals("deg"))
            {
                unitsSpecifier = Inventor.UnitsTypeEnum.kDegreeAngleUnits;
            }
            if (units.Equals("mm"))
            {
                unitsSpecifier = Inventor.UnitsTypeEnum.kMillimeterLengthUnits;
            }
            return GetStringFromValue(value, unitsSpecifier);
        }

        [SuppressMessage("Microsoft.Security", "CA2122:DoNotIndirectlyExposeMethodsWithLinkDemands")]
        public static string GetInventorPath()
        {
            Process currentProcess = Process.GetCurrentProcess();

            return System.IO.Path.GetDirectoryName(currentProcess.MainModule.FileName);
        }

        public static string GetStringFromValue(global::Inventor.Parameter parameter)
        {
            try
            {
                if(parameter.Value is string || parameter.Value is bool)
                    return parameter.Value.ToString();

                return Application.UnitsOfMeasure.GetStringFromValue(parameter.ModelValue, parameter.get_Units());
            }
            catch
            {
                return "*Error*";
            }
        }

        public static Inventor.ObjectTypeEnum GetObjectType(object obj)
        {
            Type invokeType = obj.GetType();

            object result = invokeType.InvokeMember("Type",
              BindingFlags.GetProperty, null, obj, null);

            return (global::Inventor.ObjectTypeEnum)result;
        }

        public static System.Object GetProperty(System.Object obj,
           string property)
        {
            try
            {
                System.Object objType = obj.GetType().InvokeMember(
                    property,
                    System.Reflection.BindingFlags.GetProperty,
                    null,
                    obj,
                    null,
                    null, null, null);

                return objType;
            }
            catch
            {
                return null;
            }
        }

        public static string GetBaseUnits(Inventor.Parameter parameter)
        {
            if (parameter.get_Units().Equals("deg"))
            {
                return "rad";
            }

            return "mm";
        }
    }

    class iLogicUtilities
    {
        private static string iLogicAddinGuid = "{3BDD8D79-2179-4B11-8A5A-257B1C0263AC}";
        
        private static IiLogicAutomation _iLogicAutomation = null;

        public static IiLogicAutomation GetiLogicAutomation()
        {
            try
            {
                if (_iLogicAutomation == null)
                {
                    Inventor.ApplicationAddIn addin =
                        InventorUtilities.Application.ApplicationAddIns.get_ItemById(iLogicAddinGuid);

                    if (addin.Activated == false)
                        addin.Activate();

                    _iLogicAutomation = (IiLogicAutomation)addin.Automation;
                }

                return _iLogicAutomation;
            }
            catch
            {
                return null;
            }
        }
    }
}
