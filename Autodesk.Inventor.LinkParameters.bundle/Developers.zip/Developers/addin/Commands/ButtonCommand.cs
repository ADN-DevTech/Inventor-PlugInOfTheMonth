﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the authors can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Drawing;
using System.IO;
using Autodesk.ADN.LinkParameters.AddIn;

namespace Autodesk.ADN.LinkParameters.Commands
{
    abstract class ButtonCommand : Command
    {
        #region Members

        protected global::Inventor.ButtonDefinition _controlDef;
        protected Icon _standardIcon;
        protected Icon _largeIcon;

        #endregion

        protected ButtonCommand()
        {
        }

        #region Command Members

        public override global::Inventor.ControlDefinition ControlDefinition
        {
            get { return (global::Inventor.ControlDefinition)_controlDef; }
        }

        public override void CreateControl()
        {
            global::Inventor.CommandManager commandMgr = Application.CommandManager;
            stdole.IPictureDisp standardIconPict = null,
                largeIconPict = null;

            if (StandardIcon != null)
            {
                standardIconPict = PictureDispConverter.ToIPictureDisp(StandardIcon);
            }
            if (LargeIcon != null)
            {
                largeIconPict = PictureDispConverter.ToIPictureDisp(LargeIcon);
            }
            _controlDef = commandMgr.ControlDefinitions.AddButtonDefinition(DisplayName,
                InternalName, Classification, Globals.AddInGUIDRegString,
                Description,
                ToolTipText,
                standardIconPict, largeIconPict,
                ButtonDisplay);
            _controlDef.OnExecute += new global::Inventor.ButtonDefinitionSink_OnExecuteEventHandler(Handle_ButtonDefinition_OnExecute);
            _controlDef.OnHelp += new global::Inventor.ButtonDefinitionSink_OnHelpEventHandler(Handle_ButtonDefinition_OnHelp);
        }

        #endregion

        abstract protected void OnExecute(global::Inventor.NameValueMap context);
        abstract protected void OnHelp(global::Inventor.NameValueMap context);

        public virtual string StandardIconName
        {
            get { return string.Empty; }
        }

        public virtual string LargeIconName
        {
            get { return string.Empty; }
        }

        protected Icon StandardIcon
        {
            get
            {
                if ((_standardIcon == null) && (string.IsNullOrEmpty(StandardIconName) == false))
                {
                    _standardIcon = GetIcon(StandardIconName, new Size(16, 16));
                }
                return _standardIcon;
            }
        }

        protected Icon LargeIcon
        {
            get
            {
                if ((_largeIcon == null) && (string.IsNullOrEmpty(LargeIconName) == false))
                {
                    _largeIcon = GetIcon(LargeIconName, new Size(32, 32));
                }
                return _largeIcon;
            }
        }

        private Icon GetIcon(string name, Size size)
        {
            Stream resourceStream = GetType().Assembly.GetManifestResourceStream(name);

            return new Icon(resourceStream, size);
        }

        private void Handle_ButtonDefinition_OnExecute(global::Inventor.NameValueMap context)
        {
            try
            {
                OnExecute(context);
            }
            catch
            {
            }
        }

        private void Handle_ButtonDefinition_OnHelp(global::Inventor.NameValueMap context, out global::Inventor.HandlingCodeEnum handlingCode)
        {
            handlingCode = global::Inventor.HandlingCodeEnum.kEventHandled;

            try
            {
                OnHelp(context);
            }
            catch 
            {
            }
        }
    }
}
