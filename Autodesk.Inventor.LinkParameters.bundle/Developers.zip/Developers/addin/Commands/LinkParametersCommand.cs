﻿////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Copyright (c) Autodesk, Inc. All rights reserved 
// Written by Jan Liska & Philippe Leefsma 2011 - ADN/Developer Technical Services
//
// This software is provided as is, without any warranty that it will work. You choose to use this tool at your own risk.
// Neither Autodesk nor the authors can be taken as responsible for any damage this tool can cause to 
// your data. Please always make a back up of your data prior to use this tool.
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using Inventor;
using Autodesk.ADN.LinkParameters.AddIn;
using Autodesk.ADN.LinkParameters.UI;

namespace Autodesk.ADN.LinkParameters.Commands
{
    [Command("iLogicTools.LinkParametersCmd")]
    class LinkParametersCommand : ButtonCommand
    {
        public enum CommandState
        {
            Idle,
            SourceComponentSelection,
            TargetComponentSelection,
        };

        #region Fields

        private static LinkParametersForm _frm;

        private global::Inventor.ComponentOccurrence _sourceComponent;
        private global::Inventor.ComponentOccurrence _targetComponent;
        private CommandState _state;
        private InteractionManager _InteractionManager;

        #endregion


        #region Events

        internal event EventHandler<EventArgs> SourceComponentSelected;
        internal event EventHandler<EventArgs> TargetComponentSelected;

        #endregion

        #region ButtonCommand Members

        public override string DisplayName
        {
            get { return "Link Parameters"; }
        }

        public override string Description
        {
            get { return "Links parameters between parts"; }
        }

        public override string ToolTipText
        {
            get { return "Link Parameters"; }
        }

        public override string StandardIconName
        {
            get { return "Autodesk.ADN.LinkParameters.Resources.LinkParameters.16x16.ico"; }
        }

        public override string LargeIconName
        {
            get { return "Autodesk.ADN.LinkParameters.Resources.LinkParameters.32x32.ico"; }
        }

        protected override void OnExecute(global::Inventor.NameValueMap context)
        {
            StartCommand();
        }

        protected override void OnHelp(global::Inventor.NameValueMap context)
        {
        }

        #endregion


        public CommandState State
        {
            get 
            { 
                return _state; 
            }
        }

        internal global::Inventor.ComponentOccurrence SourceComponent
        {
            get 
            { 
                return _sourceComponent; 
            }
            set
            {
                _sourceComponent = value;
            }
        }

        internal global::Inventor.ComponentOccurrence TargetComponent
        {
            get 
            { 
                return _targetComponent; 
            }
            set
            {
                _targetComponent = value;
            }
        }

        internal void SelectSourceComponent()
        {
            _state = CommandState.SourceComponentSelection;

            _InteractionManager.StopSelect();

            _InteractionManager.Reset();

            _InteractionManager.SelectEvents.SingleSelectEnabled = true;

            _InteractionManager.SelectEvents.AddSelectionFilter(
                Inventor.SelectionFilterEnum.kAssemblyLeafOccurrenceFilter);

           _InteractionManager.DoSelect("Select source component");
        }

        internal void SelectTargetComponent()
        {
            _state = CommandState.TargetComponentSelection;

            _InteractionManager.StopSelect();

            _InteractionManager.Reset();

            _InteractionManager.SelectEvents.SingleSelectEnabled = true;

            _InteractionManager.SelectEvents.AddSelectionFilter(
                Inventor.SelectionFilterEnum.kAssemblyLeafOccurrenceFilter);

            _InteractionManager.DoSelect("Select target component");
        }

        private void StartCommand()
        {
            if (_frm != null)
            {
                if (!_frm.Visible)
                {
                    _frm.Dispose();
                }

                _frm.Focus();
                return;
            }

            RuleNameForm ruleNameForm = new RuleNameForm();

            System.Windows.Forms.DialogResult res = 
                ruleNameForm.ShowModal();

            if (res != System.Windows.Forms.DialogResult.OK)
                return;

            ruleNameForm.Dispose();

            _frm = new LinkParametersForm(ruleNameForm.RuleName);
            _frm.Command = this;
            _frm.FormClosed += new System.Windows.Forms.FormClosedEventHandler(Handle_Form_FormClosed);

            _frm.Show(new WinUtilities((IntPtr)InventorUtilities.Application.MainFrameHWND));
            
            if (_frm.TopMost == false)
            {
                _frm.BringToFront();
                _frm.Activate();
            }

            _InteractionManager = new InteractionManager(InventorUtilities.Application);

            _InteractionManager.Initialize();

            _InteractionManager.SelectEvents.OnSelect += 
                new Inventor.SelectEventsSink_OnSelectEventHandler(SelectEvents_OnSelect);
        }

        public void StopSelection()
        {
            _InteractionManager.StopSelect();

            //System.Windows.Forms.Application.DoEvents();
        }
    
        private void TerminateCommand()
        {
            _InteractionManager.Terminate();

            if (_frm != null)
            {
                _frm.Dispose();
                _frm = null;
            }
        }

        private void Handle_Form_FormClosed(object sender, System.Windows.Forms.FormClosedEventArgs e)
        {
            TerminateCommand();
        }

        void SelectEvents_OnSelect(
            Inventor.ObjectsEnumerator JustSelectedEntities, 
            Inventor.SelectionDeviceEnum SelectionDevice, 
            Inventor.Point ModelPosition, 
            Inventor.Point2d ViewPosition, 
            Inventor.View View)
        {
            if (_state == CommandState.Idle)
                return;

            if (JustSelectedEntities.Count != 1)
                return;

            if (!(JustSelectedEntities[1] is ComponentOccurrence))
                return;

            ComponentOccurrence selectedOccurrence = JustSelectedEntities[1] as ComponentOccurrence;

            switch (_state)
            { 
                case CommandState.SourceComponentSelection:

                    if (_targetComponent != null)
                    {
                        if (selectedOccurrence.Definition == _targetComponent.Definition)
                        {
                            System.Windows.Forms.MessageBox.Show("Source and Target components cannot be the same, or refer to the same document...",
                                "Error selecting component",
                                System.Windows.Forms.MessageBoxButtons.OK,
                                System.Windows.Forms.MessageBoxIcon.Exclamation);

                            break;
                        }
                    }

                    _state = CommandState.Idle;

                    _sourceComponent = selectedOccurrence;

                    SourceComponentSelected(this, new EventArgs());

                    break;

                case CommandState.TargetComponentSelection:

                    if (_sourceComponent != null)
                    {
                        if (selectedOccurrence.Definition == _sourceComponent.Definition)
                        {
                            System.Windows.Forms.MessageBox.Show("Source and Target components cannot be the same, or refer to the same document...",
                                "Error selecting component",
                                System.Windows.Forms.MessageBoxButtons.OK,
                                System.Windows.Forms.MessageBoxIcon.Exclamation);

                            break;
                        }
                    }

                    _state = CommandState.Idle;

                    _targetComponent = selectedOccurrence;

                    TargetComponentSelected(this, new EventArgs());

                    break;

                default:
                    _state = CommandState.Idle;
                    break;
            }  
        }
    }
}
