﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ADNPlugin-LinkParameter")]
[assembly: AssemblyDescription("Inventor LinkParameters Addin")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Autodesk")]
[assembly: AssemblyProduct("Inventor LinkParameters Addin")]
[assembly: AssemblyCopyright("Copyright © Autodesk, Inc. 2011")]
[assembly: AssemblyTrademark("Autodesk")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("4b557631-5385-4164-8c8c-c17decdbd6f4")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
